function showAlert(item) {
    alert('You clicked on ' + item);
}